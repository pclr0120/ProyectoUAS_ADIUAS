export interface Iusuario {
    IDUsuario:string;
    Nom_Usu    :string;
      Ape_Pat  :string;
    Ape_Mat :string;
    Contra :string;
     Func_Usu   :string;         
      Uni_Reg :string;
     Tel_Usu   :string;   
    UA_Atenc1 :string;
     UA_Atenc2 :string;
    UA_Atenc3:string;
     Perf_Prof :string;
   Correo      :string;           
    Red_Soc :string;
     Sexo    :string;
      Status:string;
       Foto:string;
  }