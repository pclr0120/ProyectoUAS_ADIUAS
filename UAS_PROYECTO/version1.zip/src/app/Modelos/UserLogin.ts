
export class UserLogin {
    User: string;
    Pass:string;
   


}