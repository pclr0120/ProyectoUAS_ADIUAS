
export class Admin {
    $key: string;
    nombre: string;
    email: string;
    matricula: string;
    pass:string;
    telefono:string;
    direccion:string;
    estatus: string;
    eliminado:string;
}