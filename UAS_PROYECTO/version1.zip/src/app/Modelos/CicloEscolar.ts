
export class CicloEscolar {
    public IdCicloEscolar: string;
    Semestre: string;
    FechaInicio: string;
    FechaCierre: string;
 
}