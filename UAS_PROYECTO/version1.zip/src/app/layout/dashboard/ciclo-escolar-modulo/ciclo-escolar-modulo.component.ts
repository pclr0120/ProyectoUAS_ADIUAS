import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ciclo-escolar-modulo',
  templateUrl: './ciclo-escolar-modulo.component.html',
  styleUrls: ['./ciclo-escolar-modulo.component.scss']
})
export class CicloEscolarModuloComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
